package com.example.application603;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView3,textView4,textView7;
    Button button;
    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button=(Button)findViewById(R.id.button);
        editText=(EditText)findViewById(R.id.editText);
        textView3=(TextView)findViewById(R.id.textView3);
        textView4=(TextView)findViewById(R.id.textView4);
        textView7=(TextView)findViewById(R.id.textView7);
    }
    public void wie(View v){

        float b,c,d;
        String a;
        a= editText.getText().toString();

       b=Float.parseFloat(a);
       c=Float.parseFloat(a);
       d=Float.parseFloat(a);

       b=(b*8.72f)/9.81f;
       textView3.setText(String.valueOf(b));

       c=(c*3.710f)/9.81f;
       textView4.setText(String.valueOf(c));

       d=(d*24.79f)/9.81f;
       textView7.setText(String.valueOf(d));






    }
}
